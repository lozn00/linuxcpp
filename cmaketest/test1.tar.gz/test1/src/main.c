#include<stdio.h>
#include"add.c"
int main(){
printf("What are words!\n");
printf("1+1=%d\n",add(1,1));
return 0;
}
